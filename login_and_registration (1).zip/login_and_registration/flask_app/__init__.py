from flask import Flask
app = Flask(__name__)
app.secret_key = 'Scaeva does not mean left-handed'

DATABASE = 'login_and_registration_db'

from flask_bcrypt import Bcrypt
bcrypt = Bcrypt(app)