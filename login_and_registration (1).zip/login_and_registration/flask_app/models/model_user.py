from flask_app.config.mysqlconnection import connectToMySQL
from flask import flash
from flask_app import DATABASE

DATABASE = 'login_and_registration_db'

class User:
    def __init__( self , data ):
        self.id = data['id']
        self.first_name = data['first_name']
        self.last_name = data['last_name']
        self.email = data['email']
        self.hash_pw = data['hash_pw']
        self.created_at = data['created_at']
        self.updated_at = data['updated_at']
    
    # C *************************************
    @classmethod
    def create(cls, data ):
        query = "INSERT INTO users ( first_name , last_name , email, hash_pw) VALUES ( %(first_name)s , %(last_name)s , %(email)s, %(hash_pw)s);"
        return connectToMySQL(DATABASE).query_db( query, data )

    # R *************************************
    @classmethod
    def get_all(cls):
        query = "SELECT * FROM users;"
        results = connectToMySQL(DATABASE).query_db(query)
        if len(results):
            all_users = []
            for user in results:
                all_users.append( cls(user) )
        return all_users
    @classmethod
    def get_one(cls, data):
        query = "SELECT * FROM users WHERE id=%(id)s;"
        results = connectToMySQL(DATABASE).query_db(query, data)
        one_user = []
        if not results:
            return results
        return cls(results[0])

    @classmethod
    def get_one_by_email(cls, data):
        query = "SELECT * FROM users WHERE email = %(email)s;"
        results = connectToMySQL(DATABASE).query_db(query, data)
        one_user = []
        if not results:
            return results
        return cls(results[0])

    # U ************************************
    @classmethod
    def update(cls, data):
        query = "UPDATE users SET first_name=%(first_name)s , last_name=%(last_name)s , email=%(email)s, hash_pw=%(hash_pw)s WHERE id=%(id)s"
        return connectToMySQL(DATABASE).query_db(query, data)

    #***********************************D
    @classmethod
    def delete(cls, data):
        query = "DELETE FROM users WHERE id=%(id)s;"
        return connectToMySQL(DATABASE).query_db(query, data)

    # ****************************************** VALIDATIONS **************************************************

    @staticmethod
    def validate_login(data):
        is_valid = True

        if len(data['email']) < 7:
            is_valid = False
            flash('Invalid Email', 'error_login_email')

        if len(data['pw']) < 9:
            is_valid = False
            flash('Invalid Password', 'error_login_pw')

        return is_valid

    @staticmethod
    def validate_registration(data):
        is_valid = True

        if len(data['first_name']) < 3:
            is_valid = False
            flash('First Name is required', 'error_reg_first_name')

        if len(data['last_name']) < 3:
            is_valid = False
            flash('Last name is required', 'error_reg_last_name')

        if len(data['email']) < 7:
            is_valid = False
            flash('Email is required', 'error_reg_email')

        if len(data['pw']) < 9:
            is_valid = False
            flash('Password is required', 'error_reg_pw')

        if data['pw'] != data['confirm_pw']:
            is_valid = False
            flash('Passwords do not match', 'error_reg_confirm_pw')

        return is_valid



