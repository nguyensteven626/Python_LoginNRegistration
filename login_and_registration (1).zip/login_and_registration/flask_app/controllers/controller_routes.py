from flask_app import app
from flask import render_template, redirect, request, session

@app.route('/')
def user():
    if 'uuid' in session:
        return redirect('/dashboard')
    return render_template('home_page.html')

@app.route('/dashboard')
def dashboard():
    if 'uuid' not in session:
        return redirect('/')
    return render_template('dashboard.html')

